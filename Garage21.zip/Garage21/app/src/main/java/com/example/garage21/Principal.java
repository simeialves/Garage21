package com.example.garage21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Principal extends AppCompatActivity {

    EditText placa, numero_vaga, preco_total;
    Button visualizarDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        placa = findViewById(R.id.edtPlaca);
        numero_vaga = findViewById(R.id.edtNumeroVaga);
        preco_total = findViewById(R.id.edtPrecoTotal);

        visualizarDados = findViewById(R.id.btnVisualizarDados);

        Visualizar();
    }

    public void Visualizar()
    {
        visualizarDados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent veiculoForm = new Intent(getApplicationContext(), DadosVeiculo.class);

                veiculoForm.putExtra("Placa", placa.getText().toString().trim());
                veiculoForm.putExtra("Numero_Vaga", numero_vaga.getText().toString().trim());
                veiculoForm.putExtra("Preco_Total", preco_total.getText().toString().trim());

                startActivity(veiculoForm);

                placa.setText("");
                numero_vaga.setText("");
                preco_total.setText("");
            }
        });
    }
}